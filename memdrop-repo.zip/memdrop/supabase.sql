-- Выполни целиком в Supabase: SQL Editor -> New query -> Run

create table if not exists public.profiles (
  user_id    uuid primary key references auth.users (id) on delete cascade,
  balance    bigint not null default 1000 check (balance >= 0),
  inventory  jsonb  not null default '[]'::jsonb
             check (jsonb_typeof(inventory) = 'array' and jsonb_array_length(inventory) <= 5000),
  next_uid   bigint not null default 1,
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "profiles_select_own" on public.profiles
  for select to authenticated using ((select auth.uid()) = user_id);

create policy "profiles_insert_own" on public.profiles
  for insert to authenticated with check ((select auth.uid()) = user_id);

create policy "profiles_update_own" on public.profiles
  for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
